## Describe your changes

[Beginner-friendly Javascript tutorial](https://sabe.io/classes/javascript)
