# Docker

![docker](https://user-images.githubusercontent.com/39133739/47615583-b76c8880-dad6-11e8-9cb8-09149df934d5.png)

## Blogs

- [What is Docker?](https://dev.to/djangostars/what-is-docker-and-how-to-use-it-with-python-tutorial-87a)
- [Installation](https://docs.docker.com/install/linux/docker-ce/ubuntu/)
- [Why Docker?](https://dev.to/abiodunjames/why-docker-creating-a-multi-container-application-with-docker--1gpb)
- [Docker Guide](https://dev.to/drminnaar/docker-guide---part-1--57c8)

## Video Tutorial
- [Free Course](https://www.youtube.com/watch?v=h0NCZbHjIpY&list=PL9ooVrP1hQOHUKuqGuiWLQoJ-LD25KxI5) :star: 
- [Free Course](https://www.youtube.com/watch?v=4G-ALqd0OZ8):star:
