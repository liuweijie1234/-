# Huawei_Zabbix_Templates
Here are same Zabbix Templates for same Huawei devices like 

- Switches Series S5700 and Series S6700  
- Router Series NE20

Intsall Procedure :

- For Switches : Just import the template
- For NE20 Routers : First Import the Value Map and after import the template
   
