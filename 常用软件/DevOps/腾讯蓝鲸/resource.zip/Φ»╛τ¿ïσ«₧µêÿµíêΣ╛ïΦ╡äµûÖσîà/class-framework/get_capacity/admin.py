# -*- coding: utf-8 -*-

# import from apps here


# import from lib
# ===============================================================================
from django.contrib import admin
from get_capacity.models import TaskLog

admin.site.register(CapacityData)
# ===============================================================================
